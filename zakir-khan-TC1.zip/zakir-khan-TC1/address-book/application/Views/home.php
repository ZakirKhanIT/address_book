<?php include_once PATH_VIEWS . 'includes/head.php'; ?>
<?php include_once PATH_VIEWS . 'includes/header.php'; ?> 
<?php include_once PATH_VIEWS . 'includes/footer.php'; ?>