<!DOCTYPE html>
<html>    
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?=$applicationName;?></title>
        <link href="<?php echo PATH_ADDRESS ?>/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo PATH_ADDRESS ?>/assets/style.css" rel="stylesheet">
    </head>
    <body>