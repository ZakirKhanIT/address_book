        <script src="<?php echo PATH_ADDRESS ?>/assets/js/jquery.min.js"></script>
        <script src="<?php echo PATH_ADDRESS ?>/assets/js/bootstrap.min.js"></script>

        </body>
    </html>